TO RUN THE PROGRAM FOLLOW THE INSTRUCTIONS:

1. SMILE

2. python csc_assign6.py '<directors pid>' > <name_file.html>

3. type your username and hit enter

4. type your password and hit enter

5. open the html file